import { KeroCanvas } from "./canvas.js";

export class KeroPlayer {
  /**
   * 
   * @param {KeroCanvas} canvas 
   */
  constructor(canvas) {
    this._canvas = canvas;
  }
}